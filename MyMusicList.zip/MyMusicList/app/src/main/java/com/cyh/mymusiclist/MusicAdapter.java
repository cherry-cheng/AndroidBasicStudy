package com.cyh.mymusiclist;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class MusicAdapter extends RecyclerView.Adapter<MusicAdapter.NormalTextViewHolder> {
    private final LayoutInflater mLayoutInflater;
    private String[] mTitles = null;
    public MusicAdapter(Context context) {
        mTitles = context.getResources().getStringArray(R.array.music);
        mLayoutInflater = LayoutInflater.from(context);
    }
    @NonNull
    @Override
    public NormalTextViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new NormalTextViewHolder(mLayoutInflater.inflate(R.layout.item_list, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull NormalTextViewHolder normalTextViewHolder, int i) {
        normalTextViewHolder.music_name.setText(mTitles[i]);
        normalTextViewHolder.item_position.setText(i + "");
    }

    @Override
    public int getItemCount() {
        return mTitles == null ? 0 : mTitles.length;
    }

    class NormalTextViewHolder extends RecyclerView.ViewHolder {
        TextView music_name;
        TextView item_position;
        public NormalTextViewHolder(@NonNull View itemView) {
            super(itemView);
            music_name = (TextView) itemView.findViewById(R.id.music_name);
            item_position = itemView.findViewById(R.id.item_postion);
        }
    }
}
