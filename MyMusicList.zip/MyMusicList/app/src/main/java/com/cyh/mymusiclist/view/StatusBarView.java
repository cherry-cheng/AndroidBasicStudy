package com.cyh.mymusiclist.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public class StatusBarView extends View {


    public StatusBarView(Context context) {
        super(context);
    }

    public StatusBarView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public StatusBarView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
